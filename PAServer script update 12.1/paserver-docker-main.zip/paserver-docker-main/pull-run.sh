#!/bin/bash

docker pull radstudio/paserver:latest

bash ./run.sh
